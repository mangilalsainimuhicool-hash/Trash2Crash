const login = (email, password, remember = true) => {
  const savedAccount = localStorage.getItem('ttc_account');

  if (!savedAccount) {
    showToast('No account found. Please create an account first.', 'info');
    return null;
  }

  const account = JSON.parse(savedAccount);

  if (
    account.email.toLowerCase() !== email.toLowerCase() ||
    account.password !== password
  ) {
    showToast('Invalid email or password.', 'error');
    return null;
  }

  const loggedInUser = {
    name: account.name,
    email: account.email,
    phone: account.phone,
    address: account.address,
    city: account.city,
    pincode: account.pincode,
    memberSince: account.memberSince
  };

  setUser(loggedInUser);

  if (remember) {
    localStorage.setItem('ttc_user', JSON.stringify(loggedInUser));
  }

  showToast(`Welcome back, ${loggedInUser.name}!`, 'success');

  return loggedInUser;
};