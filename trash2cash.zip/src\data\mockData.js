export const WASTE_RATES = {
  paper: 18,
  plastic: 25,
  metal: 40,
  ewaste: 60,
};

export const WASTE_CATEGORIES = [
  {
    id: 'paper',
    name: 'Paper',
    rate: 18,
    unit: 'kg',
    icon: 'Newspaper',
    emoji: '📰',
    popular: true,
    tagline: 'Save trees & conserve clean water',
    description: 'Newspapers, cardboard boxes, old textbooks, office stationery, paper bags, and mixed magazines.',
    acceptedItems: [
      'Newspapers & Gazettes',
      'Corrugated Cardboard Boxes',
      'School & College Textbooks',
      'White Office & Printer Paper',
      'Magazines & Envelopes'
    ],
    notAccepted: [
      'Wet or greasy paper (e.g., pizza boxes)',
      'Wax-coated paper cups & plates',
      'Used tissue / carbon paper'
    ],
    environmentalImpact: 'Recycling 54 kg of paper saves 1 mature tree and 2,600 liters of fresh water.'
  },
  {
    id: 'plastic',
    name: 'Plastic',
    rate: 25,
    unit: 'kg',
    icon: 'Bottle',
    emoji: '🧴',
    popular: true,
    tagline: 'Stop landfill pollution & ocean waste',
    description: 'PET water bottles, HDPE milk jugs, rigid plastic containers, food packaging, and clean plastic drums.',
    acceptedItems: [
      'PET Beverage & Mineral Water Bottles',
      'HDPE Shampoo & Detergent Jugs',
      'Rigid buckets, tubs, & chairs',
      'Clean polythene packaging covers',
      'Plastic crates & containers'
    ],
    notAccepted: [
      'Thin single-use wrappers contaminated with oil',
      'Thermocol / Styrofoam (expanded polystyrene)',
      'Hazardous pesticide or medical bottles'
    ],
    environmentalImpact: 'Recycling 1 ton of plastic saves 5,774 kWh of electricity and 16.3 barrels of crude oil.'
  },
  {
    id: 'metal',
    name: 'Metal',
    rate: 40,
    unit: 'kg',
    icon: 'Hammer',
    emoji: '🔩',
    popular: false,
    tagline: 'Infinite recyclability with zero quality loss',
    description: 'Iron scraps, aluminum beverage cans, copper wiring, brass utensils, tins, and kitchen cookware.',
    acceptedItems: [
      'Aluminum beverage cans & foil trays',
      'Iron rods, grilles, and scrap metal',
      'Brass utensils, taps & fittings',
      'Clean copper wires and stripped pipes',
      'Tin cans and stainless steel utensils'
    ],
    notAccepted: [
      'Aerosol spray cans with residual chemicals',
      'Radioactive or toxic contaminated scrap',
      'Paint cans with wet chemical paint'
    ],
    environmentalImpact: 'Recycling metal uses 95% less energy than producing virgin metal from raw bauxite ore.'
  },
  {
    id: 'ewaste',
    name: 'E-Waste',
    rate: 60,
    unit: 'kg',
    icon: 'Cpu',
    emoji: '💻',
    popular: true,
    tagline: 'Safely recover precious & rare earth metals',
    description: 'Obsolete smartphones, defunct laptops, circuit boards, power cables, old printers, and electronics.',
    acceptedItems: [
      'Old smartphones, tablets & feature phones',
      'Desktop CPUs, motherboards & RAM sticks',
      'Laptops, power adapters & chargers',
      'Printers, keypads & PC peripherals',
      'Small kitchen electric appliances'
    ],
    notAccepted: [
      'Cracked CRT televisions / mercury lamps',
      'Leaking or bloated lithium battery packs',
      'Broken CFL bulbs and tube lights'
    ],
    environmentalImpact: 'Safe recycling prevents heavy metals like Lead, Cadmium, and Mercury from poisoning groundwater.'
  }
];

export const INITIAL_USER = {
  name: 'Aarav Sharma',
  email: 'aarav.sharma@example.com',
  phone: '+91 98765 43210',
  address: 'Flat 402, Green Meadows, 14th Cross',
  city: 'Bengaluru',
  pincode: '560034',
  memberSince: 'March 2024'
};

export const INITIAL_STATS = {
  totalWasteSold: 127,
  totalEarnings: 3420,
  pickupsCompleted: 8,
  co2Saved: 64
};

export const INITIAL_TRANSACTIONS = [
  {
    id: 'TXN-7281',
    date: '2026-08-28',
    wasteType: 'Plastic',
    quantity: 24,
    rate: 25,
    earnings: 600,
    status: 'Completed',
    paymentMethod: 'UPI'
  },
  {
    id: 'TXN-6914',
    date: '2026-08-15',
    wasteType: 'Paper',
    quantity: 35,
    rate: 18,
    earnings: 630,
    status: 'Completed',
    paymentMethod: 'Cash'
  },
  {
    id: 'TXN-5820',
    date: '2026-07-30',
    wasteType: 'Metal',
    quantity: 18,
    rate: 40,
    earnings: 720,
    status: 'Completed',
    paymentMethod: 'UPI'
  },
  {
    id: 'TXN-5102',
    date: '2026-07-12',
    wasteType: 'E-Waste',
    quantity: 12,
    rate: 60,
    earnings: 720,
    status: 'Completed',
    paymentMethod: 'Bank Transfer'
  },
  {
    id: 'TXN-4421',
    date: '2026-06-25',
    wasteType: 'Plastic',
    quantity: 15,
    rate: 25,
    earnings: 375,
    status: 'Completed',
    paymentMethod: 'UPI'
  },
  {
    id: 'TXN-3910',
    date: '2026-06-08',
    wasteType: 'Paper',
    quantity: 21,
    rate: 18,
    earnings: 378,
    status: 'Completed',
    paymentMethod: 'Cash'
  },
  {
    id: 'TXN-2804',
    date: '2026-09-04',
    wasteType: 'E-Waste',
    quantity: 8,
    rate: 60,
    earnings: 480,
    status: 'Scheduled',
    paymentMethod: 'UPI'
  },
  {
    id: 'TXN-2198',
    date: '2026-09-02',
    wasteType: 'Metal',
    quantity: 14,
    rate: 40,
    earnings: 560,
    status: 'Processing',
    paymentMethod: 'UPI'
  }
];

export const INITIAL_UPCOMING_PICKUPS = [
  {
    id: 'TTC-94812',
    wasteType: 'E-Waste',
    quantity: 8,
    rate: 60,
    estimatedEarnings: 480,
    date: '2026-09-05',
    timeSlot: '9:00 AM - 12:00 PM',
    address: 'Flat 402, Green Meadows, 14th Cross, Bengaluru, 560034',
    status: 'Scheduled',
    agentName: 'Ramesh Kumar (Recycle Partner #402)',
    agentPhone: '+91 98450 11223'
  }
];

export const HOW_IT_WORKS_STEPS = [
  {
    step: '01',
    title: 'Select Your Waste',
    subtitle: 'Segregate with ease',
    description: 'Sort your dry recyclables into Paper, Plastic, Metal, or E-Waste using our simple accepted items guide.',
    icon: 'CheckCircle2'
  },
  {
    step: '02',
    title: 'Enter Quantity',
    subtitle: 'Transparent instant rates',
    description: 'Enter your estimated weight in kilograms. Our dynamic real-time calculator estimates your payout instantly.',
    icon: 'Calculator'
  },
  {
    step: '03',
    title: 'Schedule Pickup',
    subtitle: 'Zero-effort doorstep visit',
    description: 'Choose your preferred date and convenient 3-hour time slot. Our verified green agent arrives right at your doorstep.',
    icon: 'CalendarClock'
  },
  {
    step: '04',
    title: 'Get Paid',
    subtitle: 'Immediate cash or UPI transfer',
    description: 'Items are weighed in front of you on certified digital scales. Receive instantaneous payment via UPI or cash.',
    icon: 'Coins'
  }
];

export const IMPACT_METRICS = [
  {
    label: 'Waste Recycled',
    value: '52,400+ kg',
    subtext: 'Diverted from toxic landfills',
    icon: 'Recycle'
  },
  {
    label: 'CO₂ Reduced',
    value: '26,800+ kg',
    subtext: 'Offset carbon footprint',
    icon: 'Leaf'
  },
  {
    label: 'Active Users',
    value: '14,200+',
    subtext: 'Eco-conscious citizens',
    icon: 'Users'
  },
  {
    label: 'Pickups Completed',
    value: '9,850+',
    subtext: '100% verified digital weighing',
    icon: 'Truck'
  }
];

export const TIME_SLOTS = [
  '9:00 AM - 12:00 PM',
  '12:00 PM - 3:00 PM',
  '3:00 PM - 6:00 PM'
];
