import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Recycle,
  User,
  Mail,
  Phone,
  Lock,
  ArrowRight,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { useApp } from '../context/AppContext';

const Signup = () => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [errors, setErrors] = useState({});

  const { signup } = useApp();
  const navigate = useNavigate();

  const validate = () => {
    const errs = {};
    if (!fullName.trim()) errs.fullName = 'Full Name is required';

    if (!email.trim()) {
      errs.email = 'Email address is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      errs.email = 'Enter a valid email address';
    }

    if (!phone.trim()) {
      errs.phone = 'Phone number is required';
    } else if (!/^\+?[0-9]{10,12}$/.test(phone.replace(/\s+/g, ''))) {
      errs.phone = 'Enter a valid 10-digit mobile number';
    }

    if (!password) {
      errs.password = 'Password is required';
    } else if (password.length < 6) {
      errs.password = 'Password must be at least 6 characters';
    }

    if (password !== confirmPassword) {
      errs.confirmPassword = 'Passwords do not match';
    }

    if (!termsAccepted) {
      errs.terms = 'You must agree to the Terms & Conditions';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSignup = (e) => {
    e.preventDefault();
    if (!validate()) return;

    signup({
      fullName: fullName.trim(),
      email: email.trim(),
      phone: phone.trim()
    });

    navigate('/dashboard');
  };

  return (
    <div className="page-wrapper auth-page">
      <div className="auth-card-container">
        <div className="auth-card signup-card">
          {/* Brand Header */}
          <div className="auth-header text-center">
            <Link to="/" className="auth-logo-link">
              <span className="brand-icon-wrapper">
                <Recycle size={28} className="brand-icon" />
              </span>
            </Link>
            <h1 className="auth-title">Create your account</h1>
            <p className="auth-subtitle">
              Join 14,000+ citizens turning dry recyclable scrap into cash.
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSignup} className="auth-form" noValidate>
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <div className="input-with-icon">
                <User size={18} className="input-icon" />
                <input
                  type="text"
                  placeholder="e.g. Priya Nair"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className={`form-input ${errors.fullName ? 'input-error' : ''}`}
                />
              </div>
              {errors.fullName && <p className="error-msg">{errors.fullName}</p>}
            </div>

            <div className="form-row-dual">
              <div className="form-group">
                <label className="form-label">Email Address</label>
                <div className="input-with-icon">
                  <Mail size={18} className="input-icon" />
                  <input
                    type="email"
                    placeholder="name@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={`form-input ${errors.email ? 'input-error' : ''}`}
                  />
                </div>
                {errors.email && <p className="error-msg">{errors.email}</p>}
              </div>

              <div className="form-group">
                <label className="form-label">Phone Number</label>
                <div className="input-with-icon">
                  <Phone size={18} className="input-icon" />
                  <input
                    type="tel"
                    placeholder="98765 43210"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className={`form-input ${errors.phone ? 'input-error' : ''}`}
                  />
                </div>
                {errors.phone && <p className="error-msg">{errors.phone}</p>}
              </div>
            </div>

            <div className="form-row-dual">
              <div className="form-group">
                <label className="form-label">Password</label>
                <div className="input-with-icon">
                  <Lock size={18} className="input-icon" />
                  <input
                    type="password"
                    placeholder="At least 6 chars"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className={`form-input ${errors.password ? 'input-error' : ''}`}
                  />
                </div>
                {errors.password && <p className="error-msg">{errors.password}</p>}
              </div>

              <div className="form-group">
                <label className="form-label">Confirm Password</label>
                <div className="input-with-icon">
                  <Lock size={18} className="input-icon" />
                  <input
                    type="password"
                    placeholder="Re-type password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className={`form-input ${errors.confirmPassword ? 'input-error' : ''}`}
                  />
                </div>
                {errors.confirmPassword && (
                  <p className="error-msg">{errors.confirmPassword}</p>
                )}
              </div>
            </div>

            {/* Terms checkbox */}
            <div className="form-terms-row">
              <label className="checkbox-label terms-checkbox">
                <input
                  type="checkbox"
                  checked={termsAccepted}
                  onChange={(e) => setTermsAccepted(e.target.checked)}
                />
                <span>
                  I agree to the <a href="#terms" onClick={(e) => { e.preventDefault(); alert("Trash-to-Cash Terms: Scrap must be dry, non-hazardous, and segregated."); }}>Terms of Service</a> and <a href="#privacy" onClick={(e) => { e.preventDefault(); alert("Trash-to-Cash Privacy: Data is kept confidential and secure."); }}>Privacy Policy</a>
                </span>
              </label>
              {errors.terms && <p className="error-msg">{errors.terms}</p>}
            </div>

            <button type="submit" className="btn-primary w-full auth-submit-btn">
              <span>Create Account</span>
              <ArrowRight size={18} />
            </button>
          </form>

          {/* Footer link */}
          <p className="auth-footer-prompt">
            Already have an account?{' '}
            <Link to="/login" className="auth-link-bold">
              Log In
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Signup;
