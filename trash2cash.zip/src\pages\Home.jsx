import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  Sparkles,
  ShieldCheck,
  Truck,
  Wallet,
  Scale,
  Leaf,
  ChevronRight,
  TrendingUp,
  Clock,
  Award,
  CheckCircle2
} from 'lucide-react';
import WasteCard from '../components/WasteCard';
import StatCard from '../components/StatCard';
import { useApp } from '../context/AppContext';
import { HOW_IT_WORKS_STEPS } from '../data/mockData';

const Home = () => {
  const { categories, rates } = useApp();
  const navigate = useNavigate();

  // Interactive Live Calculator in Hero
  const [calculatorCategory, setCalculatorCategory] = useState('plastic');
  const [calculatorQty, setCalculatorQty] = useState(15);

  const currentRate = rates[calculatorCategory] || 25;
  const estimatedHeroEarnings = calculatorQty * currentRate;

  const handleHeroSellNow = () => {
    navigate(`/sell-waste?category=${calculatorCategory}&qty=${calculatorQty}`);
  };

  return (
    <div className="page-wrapper home-page">
      {/* HERO SECTION */}
      <section className="hero-section">
        <div className="container hero-container">
          <div className="hero-content">
            <div className="hero-badge">
              <span className="badge-pulse"></span>
              <span className="badge-text">SMART RECYCLING PLATFORM</span>
            </div>

            <h1 className="hero-title">
              Turn Your Waste Into <span className="text-highlight">Cash.</span>
            </h1>

            <p className="hero-description">
              India's premier digital scrap recycling network. Schedule effortless doorstep pickups, get verified digital weighing, and receive guaranteed instant cash or UPI payouts for your paper, plastic, metal, and electronic scrap.
            </p>

            <div className="hero-actions">
              <Link to="/sell-waste" className="btn-primary hero-btn">
                <span>Sell Your Waste</span>
                <ArrowRight size={18} />
              </Link>
              <Link to="/how-it-works" className="btn-secondary hero-btn">
                <span>How It Works</span>
              </Link>
            </div>

            {/* Quick trust metrics */}
            <div className="hero-trust-row">
              <div className="trust-item">
                <ShieldCheck size={18} className="text-green" />
                <span>100% Certified Weighing</span>
              </div>
              <div className="trust-item">
                <Wallet size={18} className="text-green" />
                <span>Instant Doorstep UPI</span>
              </div>
              <div className="trust-item">
                <Truck size={18} className="text-green" />
                <span>Zero Pickup Charges</span>
              </div>
            </div>
          </div>

          {/* Waste -> Value Interactive Card */}
          <div className="hero-card-column">
            <div className="waste-value-card">
              <div className="card-top-tag">
                <Sparkles size={16} className="text-green" />
                <span>Live Scrap-to-Value Estimator</span>
              </div>

              <div className="calculator-tabs">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setCalculatorCategory(cat.id)}
                    className={`calc-tab ${calculatorCategory === cat.id ? 'active' : ''}`}
                  >
                    <span className="tab-emoji">{cat.emoji}</span>
                    <span className="tab-name">{cat.name}</span>
                  </button>
                ))}
              </div>

              <div className="calculator-controls">
                <div className="calc-row-header">
                  <span className="calc-label">Estimated Quantity (KG):</span>
                  <span className="calc-value-badge">{calculatorQty} kg</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="100"
                  step="1"
                  value={calculatorQty}
                  onChange={(e) => setCalculatorQty(Number(e.target.value))}
                  className="calc-range-slider"
                />
                <div className="slider-limits">
                  <span>5 kg</span>
                  <span>50 kg</span>
                  <span>100 kg</span>
                </div>
              </div>

              <div className="calculator-result-box">
                <div className="calc-result-left">
                  <span className="res-label">Current Market Rate</span>
                  <span className="res-rate">₹{currentRate} / kg</span>
                </div>
                <div className="calc-result-divider"></div>
                <div className="calc-result-right">
                  <span className="res-label">Estimated Payout</span>
                  <span className="res-amount">₹{estimatedHeroEarnings}</span>
                </div>
              </div>

              <button onClick={handleHeroSellNow} className="btn-primary w-full calc-cta-btn">
                <span>Lock Price & Schedule Pickup</span>
                <ArrowRight size={18} />
              </button>

              <p className="card-note">
                <Clock size={13} />
                <span>Pickup slots available for today & tomorrow</span>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* WASTE PRICES TICKER BOARD */}
      <section className="live-prices-section">
        <div className="container">
          <div className="section-header-compact">
            <div>
              <span className="sub-badge">DAILY SCRAP RATES</span>
              <h2 className="section-title">Transparent Waste Prices</h2>
            </div>
            <Link to="/prices" className="view-all-link">
              <span>View Full Price Index</span>
              <ChevronRight size={18} />
            </Link>
          </div>

          <div className="price-cards-grid">
            <div className="price-item-card">
              <div className="price-item-icon bg-amber-soft">📰</div>
              <div className="price-item-info">
                <h4>Paper</h4>
                <p>Newspapers, cartons & books</p>
              </div>
              <div className="price-item-rate">
                <span className="rate-val">₹18</span>
                <span className="rate-unit">/kg</span>
              </div>
            </div>

            <div className="price-item-card">
              <div className="price-item-icon bg-blue-soft">🧴</div>
              <div className="price-item-info">
                <h4>Plastic</h4>
                <p>PET bottles & containers</p>
              </div>
              <div className="price-item-rate">
                <span className="rate-val">₹25</span>
                <span className="rate-unit">/kg</span>
              </div>
            </div>

            <div className="price-item-card">
              <div className="price-item-icon bg-slate-soft">🔩</div>
              <div className="price-item-info">
                <h4>Metal</h4>
                <p>Iron, copper, steel & aluminum</p>
              </div>
              <div className="price-item-rate">
                <span className="rate-val">₹40</span>
                <span className="rate-unit">/kg</span>
              </div>
            </div>

            <div className="price-item-card">
              <div className="price-item-icon bg-emerald-soft">💻</div>
              <div className="price-item-info">
                <h4>E-Waste</h4>
                <p>Phones, laptops & appliances</p>
              </div>
              <div className="price-item-rate">
                <span className="rate-val">₹60</span>
                <span className="rate-unit">/kg</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="how-it-works-section">
        <div className="container">
          <div className="section-header text-center">
            <span className="sub-badge">EFFORTLESS 4-STEP PROCESS</span>
            <h2 className="section-title">How Trash-to-Cash Works</h2>
            <p className="section-subtitle">
              Turning household and commercial recyclables into fair cash is now as simple as ordering groceries.
            </p>
          </div>

          <div className="how-cards-grid">
            {HOW_IT_WORKS_STEPS.map((item) => (
              <div key={item.step} className="process-card">
                <div className="step-watermark">{item.step}</div>
                <div className="step-pill">Step {item.step}</div>
                <h3 className="process-title">{item.title}</h3>
                <p className="process-subtitle">{item.subtitle}</p>
                <p className="process-desc">{item.description}</p>
              </div>
            ))}
          </div>

          <div className="how-it-works-action text-center">
            <Link to="/how-it-works" className="btn-secondary">
              <span>Read Full Guidelines & Segregation Tips</span>
              <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* WASTE CATEGORIES */}
      <section className="categories-section">
        <div className="container">
          <div className="section-header text-center">
            <span className="sub-badge">ACCEPTED RECYCLABLES</span>
            <h2 className="section-title">Waste Categories We Purchase</h2>
            <p className="section-subtitle">
              Sell paper, plastic, metal scrap, and electronic waste at top market rates with instant digital verification.
            </p>
          </div>

          <div className="categories-grid">
            {categories.map((category) => (
              <WasteCard key={category.id} category={category} />
            ))}
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US / VALUE PROPOSITIONS */}
      <section className="why-us-section">
        <div className="container">
          <div className="why-us-grid">
            <div className="why-us-text">
              <span className="sub-badge">THE TRASH-TO-CASH ADVANTAGE</span>
              <h2 className="section-title">
                Why Thousands Choose Trash-to-Cash Over Local Scrap Dealers
              </h2>
              <p className="why-desc">
                Traditional scrap selling involves unfair manual scales, low ambiguous rates, and the hassle of lugging heavy items to distant kabadiwalas. Trash-to-Cash solves all of this with modern technology.
              </p>

              <div className="features-list">
                <div className="feature-item">
                  <div className="feature-icon">
                    <Scale size={20} />
                  </div>
                  <div>
                    <h4>Certified Digital Weighing Scales</h4>
                    <p>Every pickup agent carries ISO-certified Bluetooth digital scales calibrated to 10-gram accuracy.</p>
                  </div>
                </div>

                <div className="feature-item">
                  <div className="feature-icon">
                    <Wallet size={20} />
                  </div>
                  <div>
                    <h4>Instant Bank or UPI Payment</h4>
                    <p>Funds are credited directly to your UPI ID or handed as crisp cash before our agent leaves your premises.</p>
                  </div>
                </div>

                <div className="feature-item">
                  <div className="feature-icon">
                    <Leaf size={20} />
                  </div>
                  <div>
                    <h4>Green Impact Certificate</h4>
                    <p>Track exactly how many trees you saved and how much carbon footprint was avoided right on your dashboard.</p>
                  </div>
                </div>
              </div>

              <div className="why-actions">
                <Link to="/schedule-pickup" className="btn-primary">
                  <span>Schedule Your First Pickup</span>
                  <ArrowRight size={18} />
                </Link>
              </div>
            </div>

            <div className="why-us-stats-card">
              <div className="stats-box-header">
                <h3>Our Collective Impact</h3>
                <span className="live-tag">Updated Live</span>
              </div>
              <div className="stats-inner-grid">
                <StatCard
                  icon="Recycle"
                  value="52,400+ kg"
                  label="Total Waste Diverted"
                  subtext="From municipal landfills"
                />
                <StatCard
                  icon="Leaf"
                  value="26,800+ kg"
                  label="CO₂ Carbon Offset"
                  subtext="Verified by climate models"
                />
                <StatCard
                  icon="IndianRupee"
                  value="₹14.8 Lakh+"
                  label="Paid to Households"
                  subtext="Direct citizen wealth generated"
                />
                <StatCard
                  icon="Truck"
                  value="9,850+"
                  label="Zero-Emission Pickups"
                  subtext="On-time doorstep service"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FINAL CTA BANNER */}
      <section className="cta-banner-section">
        <div className="container">
          <div className="cta-banner-card">
            <div className="cta-banner-content">
              <span className="cta-mini-tag">START EARNING TODAY</span>
              <h2 className="cta-heading">Ready to Declutter and Get Paid?</h2>
              <p className="cta-subheading">
                Book a 100% free doorstep pickup in under 60 seconds. Turn your unused cartons, plastics, metal and old gadgets into instant cash.
              </p>
              <div className="cta-banner-buttons">
                <Link to="/sell-waste" className="btn-primary btn-white-invert">
                  <span>Schedule Pickup Now</span>
                  <ArrowRight size={18} />
                </Link>
                <Link to="/prices" className="btn-ghost-white">
                  <span>Check Current Rates</span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
