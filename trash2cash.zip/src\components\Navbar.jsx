import React, { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import {
  Recycle,
  Menu,
  X,
  User,
  ArrowRight,
  LogOut,
  LayoutDashboard,
  CalendarCheck
} from 'lucide-react';
import { useApp } from '../context/AppContext';

const Navbar = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const { user, logout } = useApp();
  const navigate = useNavigate();

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'How It Works', path: '/how-it-works' },
    { name: 'Categories', path: '/categories' },
    { name: 'Prices', path: '/prices' },
    { name: 'About', path: '/about' },
  ];

  const handleLogout = () => {
    logout();
    setUserDropdownOpen(false);
    navigate('/');
  };

  const closeMenus = () => {
    setMobileMenuOpen(false);
    setUserDropdownOpen(false);
  };

  return (
    <header className="navbar-container">
      <div className="navbar-inner">
        {/* Brand Logo */}
        <Link to="/" className="brand-logo" onClick={closeMenus}>
          <span className="brand-icon-wrapper">
            <Recycle className="brand-icon" size={24} />
          </span>
          <div className="brand-text-group">
            <span className="brand-title">Trash-to-Cash</span>
            
          </div>
        </Link>

        {/* Desktop Navigation Links */}
        <nav className="desktop-nav">
          {navLinks.map((link) => (
            <NavLink
              key={link.name}
              to={link.path}
              className={({ isActive }) =>
                isActive ? 'nav-link nav-link-active' : 'nav-link'
              }
            >
              {link.name}
            </NavLink>
          ))}
        </nav>

        {/* Right CTA / Auth Controls */}
        <div className="navbar-actions">
          {user ? (
            <div className="user-menu-wrapper">
              <button
                className="user-profile-btn"
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                aria-label="User menu"
              >
                <div className="user-avatar">
                  <User size={18} />
                </div>
                <span className="user-name-label">{user.name.split(' ')[0]}</span>
              </button>

              {userDropdownOpen && (
                <div className="user-dropdown-menu">
                  <div className="dropdown-header">
                    <p className="dropdown-user-name">{user.name}</p>
                    <p className="dropdown-user-email">{user.email}</p>
                  </div>
                  <hr className="dropdown-divider" />
                  <Link
                    to="/dashboard"
                    className="dropdown-item"
                    onClick={closeMenus}
                  >
                    <LayoutDashboard size={16} />
                    <span>Dashboard</span>
                  </Link>
                  <Link
                    to="/schedule-pickup"
                    className="dropdown-item"
                    onClick={closeMenus}
                  >
                    <CalendarCheck size={16} />
                    <span>Schedule Pickup</span>
                  </Link>
                  <hr className="dropdown-divider" />
                  <button
                    onClick={handleLogout}
                    className="dropdown-item logout-btn"
                  >
                    <LogOut size={16} />
                    <span>Log Out</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="auth-links">
              <Link to="/login" className="login-link">
                Login
              </Link>
              <Link to="/signup" className="signup-pill-btn">
                Sign Up
              </Link>
            </div>
          )}

          <Link to="/sell-waste" className="btn-primary sell-btn-nav">
            <span>Sell Waste</span>
            <ArrowRight size={16} />
          </Link>

          {/* Mobile Hamburger Toggle */}
          <button
            className="mobile-menu-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle mobile menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="mobile-drawer">
          <div className="mobile-drawer-inner">
            <nav className="mobile-nav-list">
              {navLinks.map((link) => (
                <NavLink
                  key={link.name}
                  to={link.path}
                  onClick={closeMenus}
                  className={({ isActive }) =>
                    isActive
                      ? 'mobile-nav-item mobile-nav-active'
                      : 'mobile-nav-item'
                  }
                >
                  {link.name}
                </NavLink>
              ))}
              <NavLink
                to="/sell-waste"
                onClick={closeMenus}
                className={({ isActive }) =>
                  isActive
                    ? 'mobile-nav-item mobile-nav-active'
                    : 'mobile-nav-item'
                }
              >
                Sell Waste
              </NavLink>
              <NavLink
                to="/schedule-pickup"
                onClick={closeMenus}
                className={({ isActive }) =>
                  isActive
                    ? 'mobile-nav-item mobile-nav-active'
                    : 'mobile-nav-item'
                }
              >
                Schedule Pickup
              </NavLink>
              <NavLink
                to="/dashboard"
                onClick={closeMenus}
                className={({ isActive }) =>
                  isActive
                    ? 'mobile-nav-item mobile-nav-active'
                    : 'mobile-nav-item'
                }
              >
                Dashboard
              </NavLink>
            </nav>

            <div className="mobile-auth-section">
              {user ? (
                <div className="mobile-user-box">
                  <div className="mobile-user-details">
                    <User size={20} className="text-green" />
                    <div>
                      <p className="font-semibold">{user.name}</p>
                      <p className="text-xs text-muted">{user.email}</p>
                    </div>
                  </div>
                  <button onClick={handleLogout} className="mobile-logout-btn">
                    <LogOut size={16} />
                    <span>Log Out</span>
                  </button>
                </div>
              ) : (
                <div className="mobile-auth-buttons">
                  <Link
                    to="/login"
                    onClick={closeMenus}
                    className="btn-secondary w-full"
                  >
                    Login
                  </Link>
                  <Link
                    to="/signup"
                    onClick={closeMenus}
                    className="btn-primary w-full"
                  >
                    Get Started
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
