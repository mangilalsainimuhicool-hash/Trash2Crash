import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Recycle,
  Mail,
  Lock,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [errors, setErrors] = useState({});
  const { login, showToast } = useApp();
  const navigate = useNavigate();

  const validate = () => {
    const errs = {};
    if (!email.trim()) {
      errs.email = 'Email address is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      errs.email = 'Please enter a valid email address';
    }

    if (!password) {
      errs.password = 'Password is required';
    } else if (password.length < 6) {
      errs.password = 'Password must be at least 6 characters';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleLogin = (e) => {
    e.preventDefault();
    if (!validate()) return;

    login(email, password, rememberMe);
    navigate('/dashboard');
  };

  const handleGoogleLogin = () => {
    login('aarav.sharma@example.com', 'demo123');
    showToast('Signed in via Google Account 👋', 'success');
    navigate('/dashboard');
  };

  const fillDemoAccount = () => {
    setEmail('aarav.sharma@example.com');
    setPassword('recycle123');
    setErrors({});
  };

  const handleForgotPassword = (e) => {
    e.preventDefault();
    showToast('Password reset link sent to your email address! 📧', 'info');
  };

  return (
    <div className="page-wrapper auth-page">
      <div className="auth-card-container">
        <div className="auth-card">
          {/* Brand Header */}
          <div className="auth-header text-center">
            <Link to="/" className="auth-logo-link">
              <span className="brand-icon-wrapper">
                <Recycle size={28} className="brand-icon" />
              </span>
            </Link>
            <h1 className="auth-title">Welcome back</h1>
            <p className="auth-subtitle">
              Log in to manage your scheduled pickups and recycling earnings.
            </p>
          </div>

          {/* Quick Demo Credentials Pill */}
          <div className="demo-credentials-banner" onClick={fillDemoAccount}>
            <Sparkles size={16} className="text-green" />
            <span>Hackathon Demo? <strong>Click to autofill test credentials</strong></span>
          </div>

          {/* Form */}
          <form onSubmit={handleLogin} className="auth-form" noValidate>
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <div className="input-with-icon">
                <Mail size={18} className="input-icon" />
                <input
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`form-input ${errors.email ? 'input-error' : ''}`}
                />
              </div>
              {errors.email && <p className="error-msg">{errors.email}</p>}
            </div>

            <div className="form-group">
              <div className="label-with-addon">
                <label className="form-label">Password</label>
                <a href="#forgot" onClick={handleForgotPassword} className="forgot-link">
                  Forgot Password?
                </a>
              </div>
              <div className="input-with-icon">
                <Lock size={18} className="input-icon" />
                <input
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`form-input ${errors.password ? 'input-error' : ''}`}
                />
              </div>
              {errors.password && <p className="error-msg">{errors.password}</p>}
            </div>

            <div className="form-remember-row">
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                />
                <span>Remember me for 30 days</span>
              </label>
            </div>

            <button type="submit" className="btn-primary w-full auth-submit-btn">
              <span>Log In</span>
              <ArrowRight size={18} />
            </button>
          </form>

          {/* Social Divider */}
          <div className="auth-divider">
            <span>or</span>
          </div>

          {/* Continue with Google */}
          <button
            type="button"
            onClick={handleGoogleLogin}
            className="btn-google-auth w-full"
          >
            <svg className="google-svg" viewBox="0 0 24 24" width="18" height="18">
              <path
                fill="#4285F4"
                d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
              />
              <path
                fill="#34A853"
                d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.35 24 12 24z"
              />
              <path
                fill="#FBBC05"
                d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.14-1.55.38-2.27V6.58H1.25C.45 8.16 0 9.98 0 12s.45 3.84 1.25 5.42l4.03-3.15z"
              />
              <path
                fill="#EA4335"
                d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
              />
            </svg>
            <span>Continue with Google</span>
          </button>

          {/* Footer link */}
          <p className="auth-footer-prompt">
            Don't have an account yet?{' '}
            <Link to="/signup" className="auth-link-bold">
              Create Account
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
