import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  WASTE_RATES,
  WASTE_CATEGORIES,
  INITIAL_USER,
  INITIAL_STATS,
  INITIAL_TRANSACTIONS,
  INITIAL_UPCOMING_PICKUPS,
  TIME_SLOTS
} from '../data/mockData';

const AppContext = createContext();

export const AppProvider = ({ children }) => {
  // User state
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('ttc_user');
    return saved ? JSON.parse(saved) : INITIAL_USER;
  });

  // Pickups state
  const [upcomingPickups, setUpcomingPickups] = useState(() => {
    const saved = localStorage.getItem('ttc_pickups');
    return saved ? JSON.parse(saved) : INITIAL_UPCOMING_PICKUPS;
  });

  // Transactions state
  const [transactions, setTransactions] = useState(() => {
    const saved = localStorage.getItem('ttc_transactions');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  // Stats state
  const [stats, setStats] = useState(() => {
    const saved = localStorage.getItem('ttc_stats');
    return saved ? JSON.parse(saved) : INITIAL_STATS;
  });

  // Toast notification state
  const [toast, setToast] = useState(null);

  // Sync with LocalStorage
  useEffect(() => {
    localStorage.setItem('ttc_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('ttc_pickups', JSON.stringify(upcomingPickups));
  }, [upcomingPickups]);

  useEffect(() => {
    localStorage.setItem('ttc_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('ttc_stats', JSON.stringify(stats));
  }, [stats]);

  const showToast = (message, type = 'success') => {
    setToast({ message, type, id: Date.now() });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  // Add a newly scheduled pickup
  const schedulePickup = (pickupData) => {
    const categoryKey = pickupData.category.toLowerCase().replace('-', '').replace(' ', '');
    let rate = WASTE_RATES[categoryKey];
    if (!rate) {
      if (pickupData.category.toLowerCase().includes('paper')) rate = 18;
      else if (pickupData.category.toLowerCase().includes('plastic')) rate = 25;
      else if (pickupData.category.toLowerCase().includes('metal')) rate = 40;
      else if (pickupData.category.toLowerCase().includes('waste')) rate = 60;
      else rate = 25;
    }

    const qty = parseFloat(pickupData.quantity) || 0;
    const estimatedValue = Math.round(qty * rate);
    const pickupId = `TTC-${Math.floor(10000 + Math.random() * 90000)}`;

    const newPickup = {
      id: pickupId,
      wasteType: pickupData.category,
      quantity: qty,
      rate: rate,
      estimatedEarnings: estimatedValue,
      date: pickupData.date,
      timeSlot: pickupData.timeSlot || TIME_SLOTS[0],
      address: `${pickupData.address}, ${pickupData.city} - ${pickupData.pincode}`,
      rawAddress: pickupData.address,
      city: pickupData.city,
      pincode: pickupData.pincode,
      status: 'Scheduled',
      agentName: 'Suresh Verma (Recycle Partner #109)',
      agentPhone: '+91 97312 44556',
      createdAt: new Date().toISOString()
    };

    const newTransaction = {
      id: `TXN-${Math.floor(1000 + Math.random() * 9000)}`,
      date: pickupData.date,
      wasteType: pickupData.category,
      quantity: qty,
      rate: rate,
      earnings: estimatedValue,
      status: 'Scheduled',
      paymentMethod: pickupData.paymentMethod || 'UPI'
    };

    setUpcomingPickups(prev => [newPickup, ...prev]);
    setTransactions(prev => [newTransaction, ...prev]);

    // Update stats
    setStats(prev => ({
      ...prev,
      totalWasteSold: prev.totalWasteSold + qty,
      totalEarnings: prev.totalEarnings + estimatedValue,
      co2Saved: prev.co2Saved + Math.round(qty * 0.5)
    }));

    showToast(`Pickup Scheduled Successfully ♻ (ID: ${pickupId})`, 'success');
    return newPickup;
  };

  const cancelPickup = (id) => {
    setUpcomingPickups(prev => prev.filter(p => p.id !== id));
    setTransactions(prev => prev.map(t => t.id === id || t.date === id ? { ...t, status: 'Cancelled' } : t));
    showToast('Pickup cancelled', 'info');
  };

  // Mock Authentication
  const login = (email, password, remember = true) => {
    // Generate friendly display name from email
    const namePart = email.split('@')[0].replace('.', ' ');
    const formattedName = namePart.charAt(0).toUpperCase() + namePart.slice(1);

    const loggedInUser = {
      ...INITIAL_USER,
      name: formattedName || 'Aarav Sharma',
      email: email,
    };
    setUser(loggedInUser);
    showToast(`Welcome back, ${loggedInUser.name}! 👋`, 'success');
    return loggedInUser;
  };

  const signup = (userData) => {
    const newUser = {
      name: userData.fullName,
      email: userData.email,
      phone: userData.phone || '+91 98765 00000',
      address: 'Indiranagar 100ft Road',
      city: 'Bengaluru',
      pincode: '560038',
      memberSince: 'Just now'
    };
    setUser(newUser);
    showToast(`Account created successfully! Welcome to Trash-to-Cash ♻`, 'success');
    return newUser;
  };

  const logout = () => {
    setUser(null);
    showToast('You have been logged out.', 'info');
  };

  return (
    <AppContext.Provider
      value={{
        user,
        rates: WASTE_RATES,
        categories: WASTE_CATEGORIES,
        upcomingPickups,
        transactions,
        stats,
        toast,
        schedulePickup,
        cancelPickup,
        login,
        signup,
        logout,
        showToast
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => useContext(AppContext);
